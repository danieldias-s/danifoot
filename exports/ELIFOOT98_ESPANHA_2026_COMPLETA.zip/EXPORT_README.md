# Elifoot 98 · Espanha 2026/27

Catálogo offline V1.1 em DRAFT. Contém 172 clubes, 172 identidades e 3.905 jogadores.
Extraia em uma pasta vazia, mantendo a estrutura de diretórios. Valide o catálogo
com `dotnet Elifoot.Api.dll offline-catalog-validate --CatalogOffline:Root=<pasta-extraída>/catalogos`.
Use a pasta validada como raiz offline. O estado DRAFT permite consulta e
impede a criação de mundos com este catálogo.

Os SHA-256 cobrem todos os arquivos da exportação, incluindo este README.
O manifesto de hashes é a única exceção. A exportação usa ordem, data e
permissões fixas. Compare arquivos gerados com os mesmos bytes de origem
e a mesma versão de Python/zlib.

O manifest segue a ordem dos quatro catálogos-base. A pasta
`catalogos/_pesquisa/espanha/2026/importacao-2026-27` contém as fontes da
importação e o inventário de ranking por valor de mercado. Os levantamentos
Opta e os relatórios de cadastro e qualidade anteriores são registros históricos.
As propostas V1.6 são evidência de pesquisa. Cada comportamento permanece
pendente de aprovação.
